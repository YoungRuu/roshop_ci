-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 15, 2016 at 05:25 PM
-- Server version: 5.6.31
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rosalesoft`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `id` int(11) NOT NULL,
  `name` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `updated` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`, `phone`, `email`, `address`, `is_deleted`, `created`, `updated`) VALUES
(1, 'Chi Nhánh Trung Tâm', NULL, NULL, NULL, 0, '2016-01-01 00:00:00', '2016-01-01 00:00:00'),
(2, 'Chi nhánh quận 9', '01239512312', 'manhd2@handsome.com', 'quận 9', 0, '2016-06-13 08:18:32', '2016-06-13 08:18:32');

-- --------------------------------------------------------

--
-- Table structure for table `cash_flow`
--

CREATE TABLE IF NOT EXISTS `cash_flow` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `price` bigint(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT '0',
  `type_cash_flow` tinyint(11) NOT NULL COMMENT '0 = PT, 1 = PC',
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_payment` int(11) NOT NULL DEFAULT '0' COMMENT '0 = tien mat, 1 = chuyen khoan',
  `cash_flow_group` int(11) NOT NULL DEFAULT '0',
  `payer_group` int(11) NOT NULL DEFAULT '0' COMMENT '1=khach hang, 2=NCC, 3=nhan vien, 4=doi tac giao hang, 5= khac',
  `accounting` tinyint(11) NOT NULL DEFAULT '1' COMMENT '1 = co, 0 = khong ',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `invoice_id` int(11) NOT NULL DEFAULT '0',
  `purchase_order_id` int(11) NOT NULL DEFAULT '0',
  `purchase_return_id` int(11) NOT NULL DEFAULT '0',
  `return_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cash_flow`
--

INSERT INTO `cash_flow` (`id`, `code`, `price`, `branch_id`, `user_id`, `customer_id`, `type_cash_flow`, `note`, `type_payment`, `cash_flow_group`, `payer_group`, `accounting`, `order_id`, `invoice_id`, `purchase_order_id`, `purchase_return_id`, `return_id`, `is_deleted`, `created`) VALUES
(1, 'PT0000001', 213213, 1, 1, 0, 0, '', 490, 0, 0, 1, 0, 2, 0, 0, 0, 0, '2016-06-10 15:39:28'),
(2, 'PT0000002', 213213, 1, 1, 0, 0, '', 490, 0, 0, 1, 0, 3, 0, 0, 0, 0, '2016-06-10 15:40:08'),
(3, 'PT0000003', 213213, 1, 1, 0, 0, '', 490, 0, 0, 1, 0, 4, 0, 0, 0, 0, '2016-06-10 15:48:14'),
(4, 'PT0000004', 213213, 1, 1, 0, 0, '', 490, 0, 0, 1, 1, 0, 0, 0, 0, 0, '2016-06-10 16:04:43'),
(5, 'PC0000005', 213213, 1, 1, 0, 1, '', 490, 0, 0, 1, 0, 0, 0, 0, 1, 0, '2016-06-10 16:43:02'),
(6, 'PC0000006', 1230, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 1, 0, 0, 0, '2016-06-10 17:03:04'),
(7, 'PC0000007', 1230, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 2, 0, 0, 0, '2016-06-10 17:04:18'),
(8, 'PC0000008', 123, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 3, 0, 0, 0, '2016-06-10 17:04:29'),
(9, 'PC0000009', 492, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 4, 0, 0, 1, '2016-06-10 17:15:23'),
(10, 'PC0000010', 1230, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 5, 0, 0, 0, '2016-06-10 17:16:40'),
(11, 'PC0000011', 1230, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 6, 0, 0, 0, '2016-06-10 17:17:03'),
(12, 'PC0000012', 123, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 0, 1, 0, 1, '2016-06-10 17:28:30'),
(13, 'PC0000013', 246, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 0, 2, 0, 1, '2016-06-10 17:29:21'),
(14, 'PC0000014', 123, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 0, 3, 0, 1, '2016-06-10 17:35:55'),
(15, 'PC0000015', 123, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 0, 4, 0, 1, '2016-06-10 17:36:26'),
(16, 'PC0000016', 123, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 0, 5, 0, 1, '2016-06-10 17:41:17'),
(17, 'PC0000017', 123, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 0, 6, 0, 0, '2016-06-10 17:42:36'),
(18, 'PC0000018', 123, 1, 1, 2, 1, '', 490, 0, 0, 1, 0, 0, 0, 7, 0, 1, '2016-06-10 17:46:44'),
(19, 'PC0000019', 123, 1, 1, 2, 1, '', 491, 0, 0, 1, 0, 0, 0, 8, 0, 0, '2016-06-13 08:15:34');

--
-- Triggers `cash_flow`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_cash_flow` BEFORE INSERT ON `cash_flow`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
DECLARE prefix varchar(2);
	set num = (select max(id) from cash_flow ); 
    set num = IFNULL(num, 0);
    set num = num +1;
    IF NEW.type_cash_flow = 1 then set prefix = 'PC';
    ELSE set prefix = 'PT';
    END IF;
	SET NEW.code = CONCAT(prefix, LPAD(num, 7, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `updated` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `parent_id`, `level`, `status`, `is_deleted`, `created`, `updated`) VALUES
(1, 'Đồ ăn nhanh', 0, 0, 0, 0, '2016-06-10 09:34:56', '2016-06-10 09:34:56');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` datetime DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT '0',
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `tax_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount_owed` int(11) NOT NULL DEFAULT '0',
  `type_customer` int(11) NOT NULL DEFAULT '0' COMMENT '0 = khach hang, 1= nha cung cap, 2= doi tac giao hang',
  `branch_id` int(11) NOT NULL,
  `debt` int(11) NOT NULL DEFAULT '0',
  `total_money` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `code`, `name`, `birthday`, `customer_group_id`, `email`, `phone`, `address`, `area`, `status`, `tax_code`, `note`, `amount_owed`, `type_customer`, `branch_id`, `debt`, `total_money`, `is_deleted`, `created`) VALUES
(2, 'NCC000001', 'Dm tuấn', '2016-06-10 00:00:00', 0, '', '', '', '238', 0, '', '', 0, 1, 1, 0, 0, 0, '2016-06-10 16:58:09'),
(3, 'KH0000003', 'Dm tuấn', '2016-06-10 00:00:00', 0, '', '', '', '238', 0, '', '', 0, 0, 1, 0, 0, 0, '2016-06-10 16:58:23'),
(4, 'KH0000004', 'Dm tuấn', '2016-06-10 00:00:00', 0, '', '', '', '238', 0, '', '', 0, 0, 1, 0, 0, 0, '2016-06-10 16:58:38'),
(5, 'NCC000005', 'Dm tuấn', '2016-06-10 00:00:00', 0, '', '', '', '238', 0, '', '', 0, 1, 1, 0, 0, 0, '2016-06-10 16:58:50'),
(6, 'DT0000006', 'Dm tuấn', '2016-06-10 00:00:00', 0, '', '', '', '238', 0, '', '', 0, 2, 1, 0, 0, 0, '2016-06-10 17:01:15');

--
-- Triggers `customers`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_customer` BEFORE INSERT ON `customers`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
DECLARE prefix varchar(3);
DECLARE prefixnum int default 7;
DECLARE checkbarcode varchar(20);
	set checkbarcode = IFNULL(NEW.code, 0);
    IF checkbarcode = 0 then 
        set num = (select max(id) from customers ); 
        set num = IFNULL(num, 0);
        set num = num +1;
        IF NEW.type_customer = 0 then set prefix = 'KH';
        ELSEIF NEW.type_customer = 1 then set prefix = 'NCC';
        set prefixnum = 6;
        ELSE set prefix = 'DT';
        END IF;
        SET NEW.code = CONCAT(prefix, LPAD(num, prefixnum, '0'));
	END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `damage_items`
--

CREATE TABLE IF NOT EXISTS `damage_items` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'loai xuat hang',
  `status` int(11) NOT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `damage_items`
--

INSERT INTO `damage_items` (`id`, `code`, `branch_id`, `user_id`, `type`, `status`, `note`, `is_deleted`, `created`) VALUES
(1, 'XH000001', 1, 1, 501, 0, '', 1, '2016-06-13 09:50:33'),
(2, 'XH000002', 1, 1, 501, 0, '', 0, '2016-06-13 09:55:17');

--
-- Triggers `damage_items`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_damage_item` BEFORE INSERT ON `damage_items`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
DECLARE checkbarcode varchar(20);
    set checkbarcode = IFNULL(NEW.code, 0);
    IF checkbarcode = 0 then 
        set num = (select max(id) from damage_items ); 
        set num = IFNULL(num, 0);
        set num = num +1;
        SET NEW.code = CONCAT('XH', LPAD(num, 6, '0'));
	END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `function` int(11) NOT NULL,
  `description` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(5000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '0= lịch sử, 1= lịch sử email gửi, 2= lịch sử sms gửi',
  `type_sent` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=khach hang, 1=nhom khach hang',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=thanh cong, 1=that bai',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `branch_id`, `user_id`, `function`, `description`, `content`, `type`, `type_sent`, `status`, `created`) VALUES
(1, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-05-16 11:55:13'),
(2, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-05-26 16:32:35'),
(3, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-04 23:18:46'),
(4, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-09 10:17:15'),
(5, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-10 08:26:38'),
(6, 0, 1, 15, 'Thêm danh mục Đồ ăn nhanh', 'Thêm danh mục Đồ ăn nhanh', 0, 0, 0, '2016-06-10 09:34:56'),
(7, 0, 1, 58, 'Thêm đơn vị sản phẩm mới: Gói', 'Thêm đơn vị sản phâm mới: Gói', 0, 0, 0, '2016-06-10 09:38:40'),
(8, 0, 1, 20, 'Thêm sản phẩm mới: Nước hoa Rose', 'Thêm sản phẩm mới: Nước hoa Rose', 0, 0, 0, '2016-06-10 10:16:55'),
(9, 1, 1, 51, 'Lập phiếu kiểm kho', 'Lập phiếu kiểm kho. Mã phiếu ', 0, 0, 0, '2016-06-10 10:42:06'),
(10, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-10 11:42:28'),
(11, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-10 14:02:33'),
(12, 1, 1, 51, 'Lập phiếu kiểm kho', 'Lập phiếu kiểm kho. Mã phiếu KK000001', 0, 0, 0, '2016-06-10 14:06:56'),
(13, 0, 1, 21, 'Cập nhật thông tin sản phẩm Nước hoa Rose, mã sản phẩm: SP0000001', 'Cập nhật thông tin sản phẩm Nước hoa Rose, mã sản phẩm: SP0000001', 0, 0, 0, '2016-06-10 14:11:25'),
(14, 0, 1, 20, 'Thêm sản phẩm mới: Dầu gọi downy', 'Thêm sản phẩm mới: Dầu gọi downy', 0, 0, 0, '2016-06-10 14:44:50'),
(15, 0, 1, 22, 'Xóa sản phẩm Dầu gọi downy', 'Xóa sản phẩm Dầu gọi downy, mã sản phẩm: SP0000002', 0, 0, 0, '2016-06-10 14:46:15'),
(16, 0, 1, 20, 'Thêm sản phẩm mới: Dầu gội Atiso', 'Thêm sản phẩm mới: Dầu gội Atiso', 0, 0, 0, '2016-06-10 14:46:45'),
(17, 0, 1, 20, 'Thêm sản phẩm mới: 11111111111111111', 'Thêm sản phẩm mới: 11111111111111111', 0, 0, 0, '2016-06-10 14:51:55'),
(18, 0, 1, 22, 'Xóa sản phẩm 11111111111111111', 'Xóa sản phẩm 11111111111111111, mã sản phẩm: SP0000004', 0, 0, 0, '2016-06-10 14:52:06'),
(19, 1, 1, 51, 'Lập phiếu kiểm kho', 'Lập phiếu kiểm kho. Mã phiếu KK000010', 0, 0, 0, '2016-06-10 15:38:10'),
(20, 0, 1, 61, 'Thêm phương thức thanh toán mới: Tiền mặt', 'Thêm phương thức thanh toán mới: Tiền mặt', 0, 0, 0, '2016-06-10 15:39:01'),
(21, 0, 1, 61, 'Thêm phương thức thanh toán mới: Chuyển khoản', 'Thêm phương thức thanh toán mới: Chuyển khoản', 0, 0, 0, '2016-06-10 15:39:16'),
(22, 1, 1, 25, 'Admin Administrator lập hóa đơn bán hàng trị giá 213.213 VND', 'Admin Administrator lập hóa đơn bán hàng trị giá 213.213 VND.\nMã hóa đơn: HD0000002', 0, 0, 0, '2016-06-10 15:39:28'),
(23, 1, 1, 25, 'Admin Administrator lập hóa đơn bán hàng trị giá 213.213 VND', 'Admin Administrator lập hóa đơn bán hàng trị giá 213.213 VND.\nMã hóa đơn: HD0000003', 0, 0, 0, '2016-06-10 15:40:08'),
(24, 1, 1, 25, 'Admin Administrator lập hóa đơn bán hàng trị giá 213.213 VND', 'Admin Administrator lập hóa đơn bán hàng trị giá 213.213 VND.\nMã hóa đơn: HD0000004', 0, 0, 0, '2016-06-10 15:48:14'),
(25, 1, 1, 51, 'Lập phiếu kiểm kho', 'Lập phiếu kiểm kho. Mã phiếu KK000011', 0, 0, 0, '2016-06-10 15:56:52'),
(26, 1, 1, 27, 'Admin Administrator lập hóa đơn đặt hàng trị giá 213.213 VND', 'Admin Administrator lập hóa đơn đặt hàng trị giá 213.213 VND.\n Mã hóa đơn: DH0000001', 0, 0, 0, '2016-06-10 16:04:43'),
(27, 1, 1, 42, 'Lập phiếu trả hàng', 'Lập phiếu trả hàng. Mã phiếu trả hàng: TH0000001', 0, 0, 0, '2016-06-10 16:43:02'),
(28, 0, 1, 32, 'Thêm Nhà cung cấp Dm tuấn', 'Thêm Nhà cung cấp Dm tuấn. Mã Nhà cung cấp: ', 0, 0, 0, '2016-06-10 16:57:26'),
(29, 0, 1, 32, 'Thêm Nhà cung cấp Dm tuấn', 'Thêm Nhà cung cấp Dm tuấn. Mã Nhà cung cấp: NCC000001', 0, 0, 0, '2016-06-10 16:58:09'),
(30, 0, 1, 29, 'Thêm Khách hàng Dm tuấn', 'Thêm Khách hàng Dm tuấn. Mã Khách hàng: KH0000003', 0, 0, 0, '2016-06-10 16:58:23'),
(31, 0, 1, 29, 'Thêm Khách hàng Dm tuấn', 'Thêm Khách hàng Dm tuấn. Mã Khách hàng: KH0000004', 0, 0, 0, '2016-06-10 16:58:38'),
(32, 0, 1, 32, 'Thêm Nhà cung cấp Dm tuấn', 'Thêm Nhà cung cấp Dm tuấn. Mã Nhà cung cấp: NCC000005', 0, 0, 0, '2016-06-10 16:58:50'),
(33, 0, 1, 35, 'Thêm Đối tác giao hàng Dm tuấn', 'Thêm Đối tác giao hàng Dm tuấn. Mã Đối tác giao hàng: DT0000006', 0, 0, 0, '2016-06-10 17:01:15'),
(34, 1, 1, 38, 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn', 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn.\n Mã nhà cung cấp: NCC000001', 0, 0, 0, '2016-06-10 17:03:04'),
(35, 1, 1, 38, 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn', 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn.\n Mã nhà cung cấp: NCC000001', 0, 0, 0, '2016-06-10 17:04:18'),
(36, 1, 1, 38, 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn', 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn.\n Mã nhà cung cấp: NCC000001', 0, 0, 0, '2016-06-10 17:04:29'),
(37, 1, 1, 38, 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn', 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn.\n Mã nhà cung cấp: NCC000001', 0, 0, 0, '2016-06-10 17:15:23'),
(38, 1, 1, 39, 'Xóa phiếu nhập hàng của nhà cung cấp Dm tuấn', 'Admin xóa phiếu nhập hàng của nhà cung cấp Dm tuấn(mã NCC: NCC000001).\nChi tiết phiếu nhập hàng\n1. Nước hoa Rose, mã sản phẩm: 213dasd, số tiền: 213.213 x 4 = 852.852 Giảm giá: 0 Tổng tiền: 492\n Tổng tiền phiếu nhập hàng: 492', 0, 0, 0, '2016-06-10 17:15:35'),
(39, 1, 1, 38, 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn', 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn.\n Mã nhà cung cấp: NCC000001', 0, 0, 0, '2016-06-10 17:16:40'),
(40, 1, 1, 38, 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn', 'Lập phiếu nhập hàng từ nhà cung cấp Dm tuấn.\n Mã nhà cung cấp: NCC000001', 0, 0, 0, '2016-06-10 17:17:03'),
(41, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-10 17:28:30'),
(42, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-10 17:29:21'),
(43, 1, 1, 41, 'Xóa phiếu trả hàng nhập', 'Xóa phiếu trả hàng nhập. Mã phiếu TH0000002\nChi tiết phiếu\n1.Nước hoa Rose, mã sản phẩm 213dasd, số tiền: 213.213 x 2 = 426.426 Giảm giá: 0 Tổng tiền: 246\nTổng tiền:246', 0, 0, 0, '2016-06-10 17:29:43'),
(44, 1, 1, 41, 'Xóa phiếu trả hàng nhập', 'Xóa phiếu trả hàng nhập. Mã phiếu TH0000001\nChi tiết phiếu\n1.Nước hoa Rose, mã sản phẩm 213dasd, số tiền: 213.213 x 1 = 213.213 Giảm giá: 0 Tổng tiền: 123\nTổng tiền:123', 0, 0, 0, '2016-06-10 17:32:39'),
(45, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-10 17:35:55'),
(46, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-10 17:36:26'),
(47, 1, 1, 41, 'Xóa phiếu trả hàng nhập', 'Xóa phiếu trả hàng nhập. Mã phiếu TH0000003\nChi tiết phiếu\n1.Nước hoa Rose, mã sản phẩm 213dasd, số tiền: 213.213 x 1 = 213.213 Giảm giá: 0 Tổng tiền: 123\nTổng tiền:123', 0, 0, 0, '2016-06-10 17:36:44'),
(48, 1, 1, 41, 'Xóa phiếu trả hàng nhập', 'Xóa phiếu trả hàng nhập. Mã phiếu TH0000004\nChi tiết phiếu\n1.Nước hoa Rose, mã sản phẩm 213dasd, số tiền: 213.213 x 1 = 213.213 Giảm giá: 0 Tổng tiền: 123\nTổng tiền:123', 0, 0, 0, '2016-06-10 17:38:48'),
(49, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-10 17:41:17'),
(50, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-10 17:42:12'),
(51, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-10 17:42:36'),
(52, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-10 17:46:32'),
(53, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-10 17:46:44'),
(54, 1, 1, 41, 'Xóa phiếu trả hàng nhập', 'Xóa phiếu trả hàng nhập. Mã phiếu TH0000007\nChi tiết phiếu\n1.Nước hoa Rose, mã sản phẩm 213dasd, số tiền: 213.213 x 1 = 213.213 Giảm giá: 0 Tổng tiền: 123\nTổng tiền:123', 0, 0, 0, '2016-06-10 17:46:59'),
(55, 1, 1, 41, 'Xóa phiếu trả hàng nhập', 'Xóa phiếu trả hàng nhập. Mã phiếu TH0000005\nChi tiết phiếu\n1.Nước hoa Rose, mã sản phẩm 213dasd, số tiền: 213.213 x 1 = 213.213 Giảm giá: 0 Tổng tiền: 123\nTổng tiền:123', 0, 0, 0, '2016-06-10 17:47:31'),
(56, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-06-13 08:14:02'),
(57, 1, 1, 40, 'Lập phiếu trả hàng nhập', 'Lập phiếu trả hàng nhập.', 0, 0, 0, '2016-06-13 08:15:34'),
(58, 0, 1, 2, 'Thêm chi nhánh Chi nhánh quận 9', 'Thêm chi nhánh Chi nhánh quận 9', 0, 0, 0, '2016-06-13 08:18:32'),
(59, 1, 1, 46, 'Lập phiếu chuyển hàng', 'Lập phiếu chuyển hàng. Mã phiếu: TRF000001', 0, 0, 0, '2016-06-13 08:46:27'),
(60, 1, 1, 46, 'Lập phiếu chuyển hàng', 'Lập phiếu chuyển hàng. Mã phiếu: TRF000002', 0, 0, 0, '2016-06-13 08:50:40'),
(61, 1, 1, 47, 'Xóa phiếu chuyển hàng', 'Xóa phiếu chuyển hàng. Mã phiếu chuyển hàng TRF000002\nChi tiết phiếu.\n1. Nước hoa Rose, mã sản phẩm: SP0000001, số tiền: 213.213 x 1 = 213.213 Giảm giá: 0 Tổng tiền: 123\nTổng tiền: 123', 0, 0, 0, '2016-06-13 08:51:19'),
(62, 1, 1, 54, 'Lập phiếu xuất hàng', 'Lập phiếu xuất hàng. Mã phiếu ', 0, 0, 0, '2016-06-13 09:50:33'),
(63, 1, 1, 54, 'Lập phiếu xuất hàng', 'Lập phiếu xuất hàng. Mã phiếu XH000002', 0, 0, 0, '2016-06-13 09:55:17'),
(64, 0, 1, 55, 'Xóa phiếu xuất hàng', 'Xóa phiếu xuất hàng. Mã phiếu XH000001', 0, 0, 0, '2016-06-13 09:55:31'),
(65, 0, 1, 6, 'Cập nhật người dùng Administrator', 'Cập nhật người dùng Administrator', 0, 0, 0, '2016-06-13 10:27:00'),
(66, 1, 1, 1, 'Tài khoản Administrator đăng nhập vào hệ thống', 'Tài khoản Administrator đăng nhập vào hệ thống', 0, 0, 0, '2016-08-20 20:40:55'),
(67, 1, 1, 26, 'Admin Administrator thực hiện xóa hóa đơn bán hàng', 'Admin Administrator thực hiện xóa hóa đơn bán hàng.\nChi tiết hóa đơn.\n1. Nước hoa Rose, mã sản phẩm: 213dasd, số tiền: 213.213 x 1 = 213.213 Giảm giá: 0 Tổng tiền: 213.213\n\nTổng tiền hóa đơn: 213.213', 0, 0, 0, '2016-08-20 20:41:23');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_control`
--

CREATE TABLE IF NOT EXISTS `inventory_control` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `total_difference` int(11) NOT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `inventory_control`
--

INSERT INTO `inventory_control` (`id`, `code`, `total_difference`, `note`, `status`, `branch_id`, `user_id`, `is_deleted`, `created`) VALUES
(9, 'KK000001', 0, 'ád', 0, 1, 1, 0, '2016-06-10 14:06:56'),
(10, 'KK000010', 5, 'kiem', 0, 1, 1, 0, '2016-06-10 15:38:10'),
(11, 'KK000011', 8, '', 0, 1, 1, 0, '2016-06-10 15:56:52');

--
-- Triggers `inventory_control`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_inventory` BEFORE INSERT ON `inventory_control`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
DECLARE checkbarcode varchar(20);
    set checkbarcode = IFNULL(NEW.code, 0);
    IF checkbarcode = 0 then 
        set num = (select max(id) from inventory_control ); 
        set num = IFNULL(num, 0);
        set num = num +1;
        SET NEW.code = CONCAT('KK', LPAD(num, 6, '0'));
	END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE IF NOT EXISTS `invoices` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) DEFAULT '0',
  `status` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_product` int(11) NOT NULL,
  `total_money_product` bigint(11) NOT NULL,
  `cash_discount` int(11) NOT NULL,
  `total_money` bigint(11) NOT NULL,
  `guest_pay_money` bigint(11) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `code`, `customer_id`, `status`, `branch_id`, `user_id`, `note`, `total_product`, `total_money_product`, `cash_discount`, `total_money`, `guest_pay_money`, `is_deleted`, `created`) VALUES
(1, '', 0, 0, 1, 1, '', 1, 213213, 0, 213213, 250000, 1, '2016-06-10 15:35:45'),
(2, 'HD0000002', 0, 0, 1, 1, '', 1, 213213, 0, 213213, 250000, 0, '2016-06-10 15:39:28'),
(3, 'HD0000003', 0, 0, 1, 1, '', 1, 213213, 0, 213213, 250000, 0, '2016-06-10 15:40:08'),
(4, 'HD0000004', 0, 0, 1, 1, '', 1, 213213, 0, 213213, 250000, 0, '2016-06-10 15:48:14');

--
-- Triggers `invoices`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_invoice` BEFORE INSERT ON `invoices`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
DECLARE checkbarcode varchar(20);
    set checkbarcode = IFNULL(NEW.code, 0);
    IF checkbarcode = 0 then 
        set num = (select max(id) from invoices ); 
        set num = IFNULL(num, 0);
        set num = num +1;
        SET NEW.code = CONCAT('HD', LPAD(num, 7, '0'));
	END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `meta`
--

CREATE TABLE IF NOT EXISTS `meta` (
  `id` int(11) NOT NULL,
  `meta_group` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `meta_key` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `meta_value` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `meta_status` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=503 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `meta`
--

INSERT INTO `meta` (`id`, `meta_group`, `meta_key`, `meta_value`, `meta_status`) VALUES
(1, 'setting', 'website', 'qlbh.com.vn', '1'),
(2, 'setting', 'name', 'Lazada', '1'),
(3, 'setting', 'address', '102 phường Đakao quận 1 TP.HCM', '1'),
(4, 'setting', 'phone', '08 6262 3838', '1'),
(5, 'setting', 'unit', '1', '1'),
(6, 'setting', 'shipping_fee', '1', '1'),
(7, 'setting', 'function_order', '1', '1'),
(8, 'setting', 'surcharge', '1', '1'),
(9, 'setting', 'change_time_sale', '1', '1'),
(10, 'key_api', 'key_login', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SL', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(11, 'key_api', 'key_user', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SM', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(12, 'key_api', 'key_branch', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SN', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(13, 'key_api', 'key_permission', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SB', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(14, 'key_api', 'key_category', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SV', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(15, 'key_api', 'key_product', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SC', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(16, 'key_api', 'key_invoice', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SX', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(17, 'key_api', 'key_order', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SZ', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(18, 'key_api', 'key_customer', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SA', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(19, 'permission', 'Admin', '{"level":0,"setting_view":1,"setting_update":1,"branch_view":1,"branch_add":1,"branch_update":1,"branch_delete":1,"print_view":1,"print_update":1,"surcharge_view":1,"surcharge_add":1,"surcharge_update":1,"surcharge_delete":1,"user_view":1,"user_add":1,"user_update":1,"user_delete":1,"permission_view":1,"permission_add":1,"permission_update":1,"permission_delete":1,"history_view":1,"report_finance_view":1,"report_users_view":1,"report_supplier_view":1,"report_sale_view":1,"report_order_view":1,"report_endday_view":1,"report_product_view":1,"report_customer_view":1,"dashboard_view":1,"category_view":1,"category_add":1,"category_update":1,"category_delete":1,"product_view":1,"product_add":1,"product_update":1,"product_delete":1,"inventory_view":1,"inventory_add":1,"inventory_delete":1,"cashflow_view":1,"cashflow_add":1,"cashflow_update":1,"cashflow_delete":1,"customer_view":1,"customer_add":1,"customer_update":1,"customer_delete":1,"supplier_view":1,"supplier_add":1,"supplier_update":1,"supplier_delete":1,"partner_view":1,"partner_add":1,"partner_update":1,"partner_delete":1,"order_view":1,"order_add":1,"order_update":1,"order_delete":1,"invoice_view":1,"invoice_add":1,"invoice_update":1,"invoice_delete":1,"return_view":1,"return_add":1,"return_update":1,"return_delete":1,"purchase_order_view":1,"purchase_order_add":1,"purchase_order_update":1,"purchase_order_delete":1,"purchase_return_view":1,"purchase_return_add":1,"purchase_return_update":1,"purchase_return_delete":1,"transfer_view":1,"transfer_add":1,"transfer_update":1,"transfer_delete":1,"damage_item_view":1,"damage_item_add":1,"damage_item_update":1,"damage_item_delete":1,"currency_view":1,"currency_add":1,"currency_update":1,"currency_delete":1,"unit_view":1,"unit_add":1,"unit_update":1,"unit_delete":1,"acreage_view":1,"acreage_add":1,"acreage_update":1,"acreage_delete":1,"cargo_view":1,"cargo_add":1,"cargo_update":1,"cargo_delete":1,"shipment_view":1,"shipment_add":1,"shipment_update":1,"shipment_delete":1,"email_view":1,"email_add":1,"email_update":1,"email_delete":1,"sms_view":1,"sms_add":1,"sms_update":1,"sms_delete":1,"discount_policy_view":1,"discount_policy_add":1,"discount_policy_update":1,"discount_policy_delete":1,"paymentsmethod_view":1,"paymentsmethod_add":1,"paymentsmethod_update":1,"paymentsmethod_delete":1,"depot_view":1,"ebiz_view":1,"ebiz_add":1,"ebiz_update":1}', '1'),
(20, 'setting', 'logo', '/uploads/20160526043302pm_23697_h2000.jpg', '1'),
(36, 'key_api', 'key_supplier', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SS', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(37, 'key_api', 'key_partner', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SD', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(38, 'key_api', 'key_purchase_order', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SF', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(44, 'key_api', 'key_purchase_return', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SG', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(109, 'key_api', 'key_return', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SH', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(110, 'key_api', 'key_cash_flow', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SJ', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(111, 'key_api', 'key_transfers', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SK', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(112, 'key_api', 'key_surcharge', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SL', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(113, 'key_api', 'key_history', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SQ', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(114, 'key_api', 'key_inventory', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SW', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(115, 'key_api', 'key_report_endday', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SE', '{"add":0,"update":0,"delete":0,"view":1,"all":1,"status":1}'),
(116, 'key_api', 'key_report_sale', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SR', '{"add":0,"update":0,"delete":0,"view":1,"all":1,"status":1}'),
(117, 'key_api', 'key_report_order', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80ST', '{"add":0,"update":0,"delete":0,"view":1,"all":1,"status":1}'),
(149, 'key_api', 'key_damage_item', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SY', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(182, 'key_api', 'key_dashboard', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SY', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(185, 'key_api', 'key_report_product', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80ST', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(186, 'key_api', 'key_report_customer', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80IS', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(187, 'key_api', 'key_report_supplier', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SO', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(188, 'key_api', 'key_report_user', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SP', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(189, 'key_api', 'key_report_financial', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80AB', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(209, 'prints', 'Đơn đặt hàng', '<table style="width:100%">\n	<tbody>\n		<tr>\n			<td>{Ten_Cua_Hang}</td>\n		</tr>\n		<tr>\n			<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\n		</tr>\n		<tr>\n			<td>Điện thoại: {So_Dien_Thoai}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Ng&agrave;y xuất: {Ngay_Thang_Nam}</p>\n\n<p><strong>H&oacute;a Đơn Đặt H&agrave;ng</strong></p>\n\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\n\n<table>\n	<tbody>\n		<tr>\n			<td>Kh&aacute;ch h&agrave;ng: {Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Địa chỉ: {Dia_Chi_Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Người xuất h&oacute;a đơn: {Nhan_Vien_Ban_Hang}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>&nbsp;</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="width:35%">Đơn gi&aacute;</td>\n			<td style="text-align:center; width:30%">SL</td>\n			<td style="text-align:right">Th&agrave;nh tiền</td>\n		</tr>\n		<tr>\n			<td colspan="3">{Ten_Hang_Hoa}</td>\n		</tr>\n		<tr>\n			<td>{Don_Gia}</td>\n			<td style="text-align:center">{So_Luong}</td>\n			<td style="text-align:right">{Thanh_Tien}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>{Ghi_Chu}</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="text-align:right">Tổng tiền h&agrave;ng:</td>\n			<td style="text-align:right">{Tong_Tien_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Giảm gi&aacute;:</td>\n			<td style="text-align:right">{Giam_Gia_Hoa_Don}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Thu kh&aacute;c:</td>\n			<td style="text-align:right">{Thu_Khac}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Kh&aacute;ch cần trả:</td>\n			<td style="text-align:right">{Tong_Cong}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n', 'print_order'),
(210, 'prints', 'Hóa Đơn', '<table style="width:100%">\n	<tbody>\n		<tr>\n			<td>{Ten_Cua_Hang}</td>\n		</tr>\n		<tr>\n			<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\n		</tr>\n		<tr>\n			<td>Điện thoại: {So_Dien_Thoai}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Ng&agrave;y xuất: {Ngay_Thang_Nam}</p>\n\n<p><strong>H&oacute;a Đơn B&aacute;n H&agrave;ng</strong></p>\n\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\n\n<table>\n	<tbody>\n		<tr>\n			<td>Kh&aacute;ch h&agrave;ng: {Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Địa chỉ: {Dia_Chi_Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Người xuất h&oacute;a đơn: {Nhan_Vien_Ban_Hang}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>&nbsp;</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="width:35%">Đơn gi&aacute;</td>\n			<td style="text-align:center; width:30%">SL</td>\n			<td style="text-align:right">Th&agrave;nh tiền</td>\n		</tr>\n		<tr>\n			<td colspan="3">{Ten_Hang_Hoa}</td>\n		</tr>\n		<tr>\n			<td>{Don_Gia}</td>\n			<td style="text-align:center">{So_Luong}</td>\n			<td style="text-align:right">{Thanh_Tien}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>{Ghi_Chu}</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="text-align:right">Tổng tiền h&agrave;ng:</td>\n			<td style="text-align:right">{Tong_Tien_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Giảm gi&aacute;:</td>\n			<td style="text-align:right">{Giam_Gia_Hoa_Don}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Thu kh&aacute;c:</td>\n			<td style="text-align:right">{Thu_Khac}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Kh&aacute;ch cần trả:</td>\n			<td style="text-align:right">{Tong_Cong}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n', 'print_invoice'),
(211, 'key_api', 'key_print', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80LS', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(212, 'prints_setting', 'Đơn đặt hàng', '<table style="width:100%">\n	<tbody>\n		<tr>\n			<td>{Ten_Cua_Hang}</td>\n		</tr>\n		<tr>\n			<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\n		</tr>\n		<tr>\n			<td>Điện thoại: {So_Dien_Thoai}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Ng&agrave;y xuất: {Ngay_Thang_Nam}</p>\n\n<p><strong>H&oacute;a Đơn Đặt H&agrave;ng</strong></p>\n\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\n\n<table>\n	<tbody>\n		<tr>\n			<td>Kh&aacute;ch h&agrave;ng: {Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Địa chỉ: {Dia_Chi_Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Người xuất h&oacute;a đơn: {Nhan_Vien_Ban_Hang}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>&nbsp;</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="width:35%">Đơn gi&aacute;</td>\n			<td style="text-align:center; width:30%">SL</td>\n			<td style="text-align:right">Th&agrave;nh tiền</td>\n		</tr>\n		<tr>\n			<td colspan="3">{Ten_Hang_Hoa}</td>\n		</tr>\n		<tr>\n			<td>{Don_Gia}</td>\n			<td style="text-align:center">{So_Luong}</td>\n			<td style="text-align:right">{Thanh_Tien}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>{Ghi_Chu}</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="text-align:right">Tổng tiền h&agrave;ng:</td>\n			<td style="text-align:right">{Tong_Tien_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Giảm gi&aacute;:</td>\n			<td style="text-align:right">{Giam_Gia_Hoa_Don}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Thu kh&aacute;c:</td>\n			<td style="text-align:right">{Thu_Khac}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Kh&aacute;ch cần trả:</td>\n			<td style="text-align:right">{Tong_Cong}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n', 'print_order'),
(213, 'prints_setting', 'Hóa Đơn', '<table style="width:100%">\n	<tbody>\n		<tr>\n			<td>{Ten_Cua_Hang}</td>\n		</tr>\n		<tr>\n			<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\n		</tr>\n		<tr>\n			<td>Điện thoại: {So_Dien_Thoai}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Ng&agrave;y xuất: {Ngay_Thang_Nam}</p>\n\n<p><strong>H&oacute;a Đơn B&aacute;n H&agrave;ng</strong></p>\n\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\n\n<table>\n	<tbody>\n		<tr>\n			<td>Kh&aacute;ch h&agrave;ng: {Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Địa chỉ: {Dia_Chi_Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Người xuất h&oacute;a đơn: {Nhan_Vien_Ban_Hang}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>&nbsp;</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="width:35%">Đơn gi&aacute;</td>\n			<td style="text-align:center; width:30%">SL</td>\n			<td style="text-align:right">Th&agrave;nh tiền</td>\n		</tr>\n		<tr>\n			<td colspan="3">{Ten_Hang_Hoa}</td>\n		</tr>\n		<tr>\n			<td>{Don_Gia}</td>\n			<td style="text-align:center">{So_Luong}</td>\n			<td style="text-align:right">{Thanh_Tien}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>{Ghi_Chu}</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="text-align:right">Tổng tiền h&agrave;ng:</td>\n			<td style="text-align:right">{Tong_Tien_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Giảm gi&aacute;:</td>\n			<td style="text-align:right">{Giam_Gia_Hoa_Don}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Thu kh&aacute;c:</td>\n			<td style="text-align:right">{Thu_Khac}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Kh&aacute;ch cần trả:</td>\n			<td style="text-align:right">{Tong_Cong}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n', 'print_invoice'),
(214, 'key_api', 'key_paymentsmethod', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80SM', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(215, 'key_api', 'key_unit', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80LS', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(216, 'key_api', 'key_currency', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80DM', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(217, 'key_api', 'key_shipment_group', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80DN', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(218, 'key_api', 'key_cargo_entry_forms', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80DN', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(229, 'key_api', 'key_acreage', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80XX', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(237, 'key_api', 'key_shipment', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80LL', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(238, 'acreage', 'AG', 'An Giang', '1'),
(239, 'acreage', 'VT', 'Vũng Tàu', '1'),
(240, 'acreage', 'BL', 'Bạc Liêu', '1'),
(241, 'acreage', 'HCM', 'Hồ Chí Minh', '1'),
(242, 'acreage', 'BK', 'Bắc Kạn', '1'),
(243, 'acreage', 'BG', 'Bắc Giang', '1'),
(244, 'acreage', 'HG', 'Hậu Giang', '1'),
(245, 'acreage', 'HY', 'Hưng Yên', '1'),
(246, 'acreage', 'BN', 'Bắc Ninh', '1'),
(247, 'acreage', 'KH', 'Khánh Hòa', '1'),
(248, 'acreage', 'BT', 'Bến Tre', '1'),
(249, 'acreage', 'KG', 'Kiên Giang', '1'),
(250, 'acreage', 'KT', 'Kon Tum', '1'),
(251, 'acreage', 'LC', 'Lai Châu', '1'),
(252, 'acreage', 'BD', 'Bình Dương', '1'),
(253, 'acreage', 'LC1', 'Lào Cai', '1'),
(254, 'acreage', 'BĐ', 'Bình Định', '1'),
(255, 'acreage', 'BP', 'Bình Phước', '1'),
(256, 'acreage', 'BT1', 'Bình Thuận', '1'),
(257, 'acreage', 'LS', 'Lạng Sơn', '1'),
(258, 'acreage', 'LĐ', 'Lâm Đồng', '1'),
(259, 'acreage', 'CM', 'Cà Mau', '1'),
(260, 'acreage', 'LA', 'Long An', '1'),
(261, 'acreage', 'NĐ', 'Nam Định', '1'),
(262, 'acreage', 'CB', 'Cao Bằng', '1'),
(263, 'acreage', 'NA', 'Nghệ An', '1'),
(264, 'acreage', 'CT', 'Cần Thơ', '1'),
(265, 'acreage', 'NB', 'Ninh Bình', '1'),
(266, 'acreage', 'NT', 'Ninh Thuận', '1'),
(267, 'acreage', 'ĐN', 'Đà Nẵng', '1'),
(268, 'acreage', 'PT', 'Phú Thọ', '1'),
(269, 'acreage', 'PY', 'Phú Yên', '1'),
(270, 'acreage', 'ĐL', 'Đắk Lắk', '1'),
(271, 'acreage', 'QB', 'Quảng Bình', '1'),
(272, 'acreage', 'ĐN1', 'Đắk Nông', '1'),
(273, 'acreage', 'QN', 'Quảng Nam', '1'),
(276, 'acreage', 'QN1', 'Quảng Ngãi', '1'),
(277, 'acreage', 'QN2', 'Quảng Ninh', '1'),
(278, 'acreage', 'ĐB', 'Điện Biên', '1'),
(279, 'acreage', 'QT', 'Quảng Trị', '1'),
(280, 'acreage', 'ST', 'Sóc Trăng', '1'),
(281, 'acreage', 'ĐN2', 'Đồng Nai', '1'),
(282, 'acreage', 'SL', 'Sơn La', '1'),
(283, 'acreage', 'TN', 'Tây Ninh', '1'),
(284, 'acreage', 'ĐT', 'Đồng Tháp', '1'),
(285, 'acreage', 'TB', 'Thái Bình', '1'),
(286, 'acreage', 'GL', 'Gia Lai', '1'),
(287, 'acreage', 'TN1', 'Thái Nguyên', '1'),
(288, 'acreage', 'TH', 'Thanh Hóa', '1'),
(289, 'acreage', 'HG1', 'Hà Giang', '1'),
(290, 'acreage', 'TTH', 'Thừa Thiên - Huế', '1'),
(291, 'acreage', 'HN', 'Hà Nam', '1'),
(292, 'acreage', 'TG', 'Tiền Giang', '1'),
(293, 'acreage', 'HN1', 'Hà Nội', '1'),
(294, 'acreage', 'TV', 'Trà Vinh', '1'),
(295, 'acreage', 'TQ', 'Tuyên Quang', '1'),
(296, 'acreage', 'HT', 'Hà Tây', '1'),
(297, 'acreage', 'VL', 'Vĩnh Long', '1'),
(298, 'acreage', 'HT1', 'Hà Tĩnh', '1'),
(299, 'acreage', 'VP', 'Vinh Phúc', '1'),
(300, 'acreage', 'YB', 'Yên Bái', '1'),
(301, 'acreage', 'HD', 'Hải Dương', '1'),
(302, 'acreage', 'HP', 'Hải Phòng', '1'),
(303, 'acreage', 'HB', 'Hòa Bình', '1'),
(314, 'key_api', 'key_depot', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80BB', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(319, 'key_api', 'key_email', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80CC', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(320, 'email_setting', 'email_setting', '{"from_email":"info@nhadatso.com","server":"email-smtp.us-east-1.amazonaws.com","port":"465","security":"ssl","username":"AKIAJCPRKVXVZY75QGJA","password":"AsXQB6MoFKz6Ei1HevZBhwSLfBhNY1e2iCAOPDWm5a0E"}', '1'),
(327, 'prints', 'Trả hàng', '<table style="width:100%">\n	<tbody>\n		<tr>\n			<td>{Ten_Cua_Hang}</td>\n		</tr>\n		<tr>\n			<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\n		</tr>\n		<tr>\n			<td>Điện thoại: {So_Dien_Thoai}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Ng&agrave;y lập h&oacute;a đơn&nbsp;: {Ngay_Thang_Nam}</p>\n\n<p>&nbsp;</p>\n\n<p><strong>H&oacute;a Đơn Trả&nbsp;H&agrave;ng</strong></p>\n\n<p>M&atilde; h&oacute;a đơn: {Ma_Hoa_Don}</p>\n\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\n\n<p>&nbsp;</p>\n\n<table>\n	<tbody>\n		<tr>\n			<td>Kh&aacute;ch h&agrave;ng: {Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Địa chỉ: {Dia_Chi_Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Người lập phiếu: {Nhan_Vien_Ban_Hang}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>&nbsp;</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="width:35%">Đơn gi&aacute;</td>\n			<td style="text-align:center; width:30%">SL</td>\n			<td style="text-align:right">Th&agrave;nh tiền</td>\n		</tr>\n		<tr>\n			<td colspan="3">{Ten_Hang_Hoa}</td>\n		</tr>\n		<tr>\n			<td>{Don_Gia}</td>\n			<td style="text-align:center">{So_Luong}</td>\n			<td style="text-align:right">{Thanh_Tien}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>{Ghi_Chu}</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="text-align:right">Tổng tiền h&agrave;ng:</td>\n			<td style="text-align:right">{Tong_Tien_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Ph&iacute; trả h&agrave;ng:</td>\n			<td style="text-align:right">{Phi_Tra_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Trả kh&aacute;ch:</td>\n			<td style="text-align:right">{Tong_Cong}</td>\n		</tr>\n	</tbody>\n</table>\n', 'print_return'),
(328, 'prints_setting', 'Trả hàng', '<table style="width:100%">\n	<tbody>\n		<tr>\n			<td>{Ten_Cua_Hang}</td>\n		</tr>\n		<tr>\n			<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\n		</tr>\n		<tr>\n			<td>Điện thoại: {So_Dien_Thoai}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>Ng&agrave;y lập h&oacute;a đơn&nbsp;: {Ngay_Thang_Nam}</p>\n\n<p>&nbsp;</p>\n\n<p><strong>H&oacute;a Đơn Trả&nbsp;H&agrave;ng</strong></p>\n\n<p>M&atilde; h&oacute;a đơn: {Ma_Hoa_Don}</p>\n\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\n\n<p>&nbsp;</p>\n\n<table>\n	<tbody>\n		<tr>\n			<td>Kh&aacute;ch h&agrave;ng: {Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Địa chỉ: {Dia_Chi_Khach_Hang}</td>\n		</tr>\n		<tr>\n			<td>Người lập phiếu: {Nhan_Vien_Ban_Hang}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>&nbsp;</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="width:35%">Đơn gi&aacute;</td>\n			<td style="text-align:center; width:30%">SL</td>\n			<td style="text-align:right">Th&agrave;nh tiền</td>\n		</tr>\n		<tr>\n			<td colspan="3">{Ten_Hang_Hoa}</td>\n		</tr>\n		<tr>\n			<td>{Don_Gia}</td>\n			<td style="text-align:center">{So_Luong}</td>\n			<td style="text-align:right">{Thanh_Tien}</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>{Ghi_Chu}</p>\n\n<table style="width:100%">\n	<tbody>\n		<tr>\n			<td style="text-align:right">Tổng tiền h&agrave;ng:</td>\n			<td style="text-align:right">{Tong_Tien_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Ph&iacute; trả h&agrave;ng:</td>\n			<td style="text-align:right">{Phi_Tra_Hang}</td>\n		</tr>\n		<tr>\n			<td style="text-align:right">Trả kh&aacute;ch:</td>\n			<td style="text-align:right">{Tong_Cong}</td>\n		</tr>\n	</tbody>\n</table>\n', 'print_return'),
(329, 'key_api', 'key_discount_policy', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80NN', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(336, 'key_api', 'key_sms', 'FWRN4CVTH6LSFK7MNAHLOCITYZNV80DD', '{"add":1,"update":1,"delete":1,"view":1,"all":1,"status":1}'),
(337, 'sms_setting', 'sms_setting', '{"sms_gateway": "http://api.nhadatso.com/smsgateway/sms?chanel=fixdefault&pass=crb9915&phone={phone}&text={message}"}', '1'),
(480, 'prints', 'Nhập hàng', '<table style="width: 100%;">\n<tbody>\n<tr>\n<td>{Ten_Cua_Hang}</td>\n</tr>\n<tr>\n<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\n</tr>\n<tr>\n<td>Điện thoại: {So_Dien_Thoai}</td>\n</tr>\n</tbody>\n</table>\n<p>Ng&agrave;y lập h&oacute;a đơn&nbsp;: {Ngay_Thang_Nam}</p>\n<p>&nbsp;</p>\n<p><strong>H&oacute;a Đơn&nbsp;Nhập H&agrave;ng</strong></p>\n<p>M&atilde; h&oacute;a đơn: {Ma_Hoa_Don}</p>\n<table>\n<tbody>\n<tr>\n<td>Nh&agrave; cung cấp: {Khach_Hang}</td>\n</tr>\n<tr>\n<td>\n<p>Khu vực: {Khu_Vuc}</p>\n<p>Địa chỉ: {Dia_Chi_Khach_Hang}</p>\n<p>MST: {Ma_So_Thue}</p>\n</td>\n</tr>\n<tr>\n<td>Người lập phiếu: {Nhan_Vien_Ban_Hang} - {Ma_Nhan_Vien}</td>\n</tr>\n</tbody>\n</table>\n<p>&nbsp;</p>\n<p>&nbsp;</p>\n<table style="width: 100%;">\n<tbody>\n<tr style="height: 48px;">\n<td style="width: 34%; height: 48px;">Đơn gi&aacute;</td>\n<td style="text-align: center; width: 19%; height: 48px;">SL</td>\n<td style="width: 14.1791%; height: 48px; text-align: center;">Giảm gi&aacute;</td>\n<td style="text-align: right; width: 27.8209%; height: 48px;">Th&agrave;nh tiền</td>\n</tr>\n<tr style="height: 48px;">\n<td style="width: 95%; height: 48px;" colspan="4">{Ten_Hang_Hoa}</td>\n</tr>\n<tr>\n<td>{Don_Gia}</td>\n<td style="text-align: center;">{So_Luong}</td>\n<td style="text-align: center;">{Giam_Gia}</td>\n<td style="text-align: right;">{Thanh_Tien}</td>\n</tr>\n</tbody>\n</table>\n<p>&nbsp;</p>\n<p>{Ghi_Chu}</p>\n<table style="width: 100%;">\n<tbody>\n<tr>\n<td style="text-align: right;">Tổng tiền h&agrave;ng:</td>\n<td style="text-align: right;">{Tong_Tien_Hang}</td>\n</tr>\n<tr>\n<td style="text-align: right;">Giảm gi&aacute;</td>\n<td style="text-align: right;">{Giam_Gia_Hoa_Don}</td>\n</tr>\n<tr>\n<td style="text-align: right;">Trả nh&agrave; cung cấp:</td>\n<td style="text-align: right;">{Tong_Cong}</td>\n</tr>\n</tbody>\n</table>', 'print_purchaseorder'),
(481, 'prints_setting', 'Nhập hàng', '<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td>{Ten_Cua_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>Điện thoại: {So_Dien_Thoai}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Ng&agrave;y lập h&oacute;a đơn&nbsp;: {Ngay_Thang_Nam}</p>\r\n<p>&nbsp;</p>\r\n<p><strong>H&oacute;a Đơn&nbsp;Nhập H&agrave;ng</strong></p>\r\n<p>M&atilde; h&oacute;a đơn: {Ma_Hoa_Don}</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Nh&agrave; cung cấp: {Khach_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Khu vực: {Khu_Vuc}</p>\r\n<p>Địa chỉ: {Dia_Chi_Khach_Hang}</p>\r\n<p>MST: {Ma_So_Thue}</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>Người lập phiếu: {Nhan_Vien_Ban_Hang} - {Ma_Nhan_Vien}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<table style="width: 100%;">\r\n<tbody>\r\n<tr style="height: 48px;">\r\n<td style="width: 34%; height: 48px;">Đơn gi&aacute;</td>\r\n<td style="text-align: center; width: 19%; height: 48px;">SL</td>\r\n<td style="width: 14.1791%; height: 48px; text-align: center;">Giảm gi&aacute;</td>\r\n<td style="text-align: right; width: 27.8209%; height: 48px;">Th&agrave;nh tiền</td>\r\n</tr>\r\n<tr style="height: 48px;">\r\n<td style="width: 95%; height: 48px;" colspan="4">{Ten_Hang_Hoa}</td>\r\n</tr>\r\n<tr style="height: 48px;">\r\n<td style="width: 34%; height: 48px;">{Don_Gia}</td>\r\n<td style="text-align: center; width: 19%; height: 48px;">{So_Luong}</td>\r\n<td style="width: 14.1791%; height: 48px; text-align: center;">{Giam_Gia}</td>\r\n<td style="text-align: right; width: 27.8209%; height: 48px;">{Thanh_Tien}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>{Ghi_Chu}</p>\r\n<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: right;">Tổng tiền h&agrave;ng:</td>\r\n<td style="text-align: right;">{Tong_Tien_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: right;">Giảm gi&aacute;</td>\r\n<td style="text-align: right;">{Giam_Gia_Hoa_Don}</td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: right;">Trả nh&agrave; cung cấp:</td>\r\n<td style="text-align: right;">{Tong_Cong}</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'print_purchaseorder'),
(482, 'prints', 'Trả hàng nhập', '<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td>{Ten_Cua_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>Điện thoại: {So_Dien_Thoai}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Ng&agrave;y lập h&oacute;a đơn&nbsp;: {Ngay_Thang_Nam}</p>\r\n<p>&nbsp;</p>\r\n<p><strong>H&oacute;a Đơn Trả&nbsp;H&agrave;ng Nhập</strong></p>\r\n<p>M&atilde; h&oacute;a đơn: {Ma_Hoa_Don}</p>\r\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\r\n<p>&nbsp;</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Nh&agrave; cung cấp: {Khach_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Khu vực: {Khu_Vuc}</p>\r\n<p>Địa chỉ: {Dia_Chi_Khach_Hang}</p>\r\n<p>MST: {Ma_So_Thue}</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>Người lập phiếu: {Nhan_Vien_Ban_Hang} - {Ma_Nhan_Vien}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td style="width: 35%;">Đơn gi&aacute;</td>\r\n<td style="text-align: center; width: 30%;">SL</td>\r\n<td style="text-align: right;">Th&agrave;nh tiền</td>\r\n</tr>\r\n<tr>\r\n<td colspan="3">{Ten_Hang_Hoa}</td>\r\n</tr>\r\n<tr>\r\n<td>{Don_Gia}</td>\r\n<td style="text-align: center;">{So_Luong}</td>\r\n<td style="text-align: right;">{Thanh_Tien}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>{Ghi_Chu}</p>\r\n<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: right;">Tổng tiền h&agrave;ng:</td>\r\n<td style="text-align: right;">{Tong_Tien_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: right;">Trả nh&agrave; cung cấp:</td>\r\n<td style="text-align: right;">{Tong_Cong}</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'print_purchasereturn'),
(483, 'prints_setting', 'Trả hàng nhập', '<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td>{Ten_Cua_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>Chi nh&aacute;nh: {Chi_Nhanh_Ban_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>Điện thoại: {So_Dien_Thoai}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Ng&agrave;y lập h&oacute;a đơn&nbsp;: {Ngay_Thang_Nam}</p>\r\n<p>&nbsp;</p>\r\n<p><strong>H&oacute;a Đơn Trả&nbsp;H&agrave;ng Nhập</strong></p>\r\n<p>M&atilde; h&oacute;a đơn: {Ma_Hoa_Don}</p>\r\n<p>M&atilde; đơn h&agrave;ng: {Ma_Don_Hang}</p>\r\n<p>&nbsp;</p>\r\n<table>\r\n<tbody>\r\n<tr>\r\n<td>Nh&agrave; cung cấp: {Khach_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Khu vực: {Khu_Vuc}</p>\r\n<p>Địa chỉ: {Dia_Chi_Khach_Hang}</p>\r\n<p>MST: {Ma_So_Thue}</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>Người lập phiếu: {Nhan_Vien_Ban_Hang} - {Ma_Nhan_Vien}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td style="width: 35%;">Đơn gi&aacute;</td>\r\n<td style="text-align: center; width: 30%;">SL</td>\r\n<td style="text-align: right;">Th&agrave;nh tiền</td>\r\n</tr>\r\n<tr>\r\n<td colspan="3">{Ten_Hang_Hoa}</td>\r\n</tr>\r\n<tr>\r\n<td>{Don_Gia}</td>\r\n<td style="text-align: center;">{So_Luong}</td>\r\n<td style="text-align: right;">{Thanh_Tien}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>{Ghi_Chu}</p>\r\n<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: right;">Tổng tiền h&agrave;ng:</td>\r\n<td style="text-align: right;">{Tong_Tien_Hang}</td>\r\n</tr>\r\n<tr>\r\n<td style="text-align: right;">Trả nh&agrave; cung cấp:</td>\r\n<td style="text-align: right;">{Tong_Cong}</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'print_purchasereturn'),
(484, 'branch_user', '1', '1', '1'),
(485, 'config_ebiz', '{"host":"118.69.78.118","port":"","username":"sa","password":"phongthuy@123.com.vn$","dbname":"thegioiphongthuy"}', '', ''),
(486, 'branch_category', '1', '1', '1'),
(487, 'unit', 'GOI', 'Gói', '0'),
(488, 'product_attribute_setting', 'dm kaka', '', ''),
(489, 'product_attribute', '1', '488', 'manh hand some'),
(490, 'paymentsmethod', 'TM', 'Tiền mặt', '0'),
(491, 'paymentsmethod', 'CK', 'Chuyển khoản', '0'),
(492, 'cargo_entry_forms', 'ND', 'Nội Địa', '0'),
(493, 'cargo_entry_forms', 'NK', 'Nhập Khẩu', '0'),
(494, 'system_error', 'purchase_order', 'rollback_inventory_product_barcode', 'SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''and branch_id=1 limit 1'' at line 1'),
(495, 'system_error', 'purchase_order', 'rollback_inventory_product_barcode', 'SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''and branch_id=1 limit 1'' at line 1'),
(496, 'system_error', 'purchase_order', 'rollback_inventory_product_barcode', 'SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''and branch_id=1 limit 1'' at line 1'),
(497, 'system_error', 'purchase_order', 'rollback_inventory_product_barcode', 'SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''and branch_id=1 limit 1'' at line 1'),
(498, 'system_error', 'purchase_order', 'rollback_inventory_product_barcode', 'SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''and branch_id=1 limit 1'' at line 1'),
(499, 'branch_user', '2', '1', '1'),
(500, 'branch_category', '2', '1', '1'),
(501, 'shipment_group', 'KM', 'Khuyến mãi', '0'),
(502, 'shipment_group', 'XT', 'Xuất tặng', '0');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) DEFAULT '0',
  `status` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receiver` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deliver_id` int(11) DEFAULT '0',
  `type_deliver` int(11) NOT NULL DEFAULT '0' COMMENT '0=nhan vien giao, 1=chuyen phat nhanh, 2=buu dien, 3=tau, 4=may bay',
  `weight` int(11) DEFAULT NULL,
  `size_length` int(11) DEFAULT NULL,
  `size_width` int(11) DEFAULT NULL,
  `size_height` int(11) DEFAULT NULL,
  `shipping_fee` int(11) DEFAULT NULL,
  `total_product` int(11) NOT NULL,
  `total_money_product` bigint(11) NOT NULL,
  `cash_discount` int(11) DEFAULT '0',
  `total_money` bigint(11) NOT NULL,
  `guest_pay_money` bigint(11) NOT NULL,
  `is_deleted` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `code`, `customer_id`, `status`, `branch_id`, `user_id`, `note`, `receiver`, `phone`, `address`, `area`, `deliver_id`, `type_deliver`, `weight`, `size_length`, `size_width`, `size_height`, `shipping_fee`, `total_product`, `total_money_product`, `cash_discount`, `total_money`, `guest_pay_money`, `is_deleted`, `created`) VALUES
(1, 'DH0000001', 0, 0, 1, 1, '', 'đá', '', '', '238', 0, 0, 1, 1, 1, 1, 0, 1, 213213, 0, 213213, 250000, 0, '2016-06-10 16:04:43');

--
-- Triggers `orders`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_order` BEFORE INSERT ON `orders`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
DECLARE checkbarcode varchar(20);
    set checkbarcode = IFNULL(NEW.code, 0);
    IF checkbarcode = 0 then 
        set num = (select max(id) from orders ); 
        set num = IFNULL(num, 0);
        set num = num +1;
        SET NEW.code = CONCAT('DH', LPAD(num, 7, '0'));
	END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `order_invoice_surcharge`
--

CREATE TABLE IF NOT EXISTS `order_invoice_surcharge` (
  `id` int(11) NOT NULL,
  `surcharge_id` int(11) NOT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `add_bill` int(11) NOT NULL DEFAULT '1',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `invoice_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `discount_amount` int(11) NOT NULL DEFAULT '0',
  `original_price` bigint(11) NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `barcode` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `note_order` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `norms_least` int(11) NOT NULL DEFAULT '0',
  `most_norms` int(11) NOT NULL DEFAULT '0',
  `original_price_last` bigint(11) NOT NULL,
  `business` int(11) NOT NULL DEFAULT '1',
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `unit` int(11) NOT NULL DEFAULT '0',
  `parent_product_id` int(11) NOT NULL DEFAULT '0',
  `exchange_value` float NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `updated` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `category_id`, `discount_amount`, `original_price`, `weight`, `barcode`, `code`, `description`, `note_order`, `image`, `norms_least`, `most_norms`, `original_price_last`, `business`, `type`, `unit`, `parent_product_id`, `exchange_value`, `is_deleted`, `created`, `updated`) VALUES
(1, 'Nước hoa Rose', 1, 0, 123, 1, 'SP0000001', '213dasd', '', '', '20160610101655am_chuong-trinh-xay-dung-van-hoa-doanh-nghiep.jpg', 1, 1000, 213213, 1, 'VND', 487, 0, 0, 0, '2016-06-10 10:16:55', '2016-06-10 14:11:25'),
(2, 'Dầu gọi downy', 1, 50000, 50000, 50000, 'SP0000002', 'http://manhsalesoft.com/SP000005', 'Đây là dầu gội downy', 'Đây là dầu gội downy', '20160610024449pm_hinh3.jpg', 50000, 50000, 50000, 1, 'VNĐ', 487, 0, 0, 1, '2016-06-10 14:44:49', '2016-06-10 14:44:49'),
(3, 'Dầu gội Atiso', 1, 50000, 50000, 50000, 'SP0000003', 'SP00005', 'Dầu gội Atiso', 'Dầu gội Atiso', '20160610024645pm_Caigivaynhi.jpg', 50000, 50000, 50000, 1, 'VNĐ', 487, 0, 0, 0, '2016-06-10 14:46:45', '2016-06-10 14:46:45'),
(4, '11111111111111111', 1, 1000000000, 10000000000, 10000000, 'SP0000004', '1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111', '11111111111111111', '11111111111111111', '20160610025155pm_hinh10.jpg', 111111, 111111, 10000000000, 1, 'VNĐ', 487, 0, 0, 1, '2016-06-10 14:51:55', '2016-06-10 14:51:55');

--
-- Triggers `product`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_barcode` BEFORE INSERT ON `product`
 FOR EACH ROW BEGIN
DECLARE num int default 0;
DECLARE checkbarcode varchar(20);
    set checkbarcode = IFNULL(NEW.barcode, 0);
    IF checkbarcode = 0 then 
    	set num = (select max(id) from product ); 
        set num = IFNULL(num, 0);
    	set num = num +1;
		SET NEW.barcode = CONCAT('SP', LPAD(num, 7, '0'));
    END IF;
	
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product_extension`
--

CREATE TABLE IF NOT EXISTS `product_extension` (
  `id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `inventory_number` int(11) NOT NULL,
  `quantity_order_active` int(11) NOT NULL,
  `is_deleted` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_extension`
--

INSERT INTO `product_extension` (`id`, `branch_id`, `product_id`, `inventory_number`, `quantity_order_active`, `is_deleted`) VALUES
(1, 1, 1, 45, 45, 0),
(2, 1, 2, 0, 0, 0),
(3, 1, 3, 0, 0, 0),
(4, 1, 4, 0, 0, 0),
(5, 2, 1, 2, 2, 0),
(6, 2, 2, 0, 0, 0),
(7, 2, 3, 0, 0, 0),
(8, 2, 4, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE IF NOT EXISTS `purchase_order` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'loai nhap hang',
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_product` int(11) NOT NULL,
  `total_money_product` bigint(11) NOT NULL,
  `cash_discount` int(11) DEFAULT '0',
  `guest_pay_money` bigint(11) NOT NULL,
  `is_deleted` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `purchase_order`
--

INSERT INTO `purchase_order` (`id`, `code`, `customer_id`, `status`, `branch_id`, `user_id`, `type`, `note`, `total_product`, `total_money_product`, `cash_discount`, `guest_pay_money`, `is_deleted`, `created`) VALUES
(2, 'NH0000001', 2, 0, 1, 1, 492, '', 10, 1230, 0, 1230, 0, '2016-06-10 17:04:18'),
(3, 'NH0000003', 2, 0, 1, 1, 492, '', 1, 123, 0, 123, 0, '2016-06-10 17:04:29'),
(4, 'NH0000004', 2, 0, 1, 1, 492, '', 4, 492, 0, 492, 1, '2016-06-10 17:15:23'),
(5, 'NH0000005', 2, 0, 1, 1, 492, '', 10, 1230, 0, 1230, 0, '2016-06-10 17:16:40'),
(6, 'NH0000006', 2, 0, 1, 1, 492, '', 10, 1230, 0, 1230, 0, '2016-06-10 17:17:03');

--
-- Triggers `purchase_order`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_purchase_order` BEFORE INSERT ON `purchase_order`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
DECLARE checkbarcode varchar(20);
    set checkbarcode = IFNULL(NEW.code, 0);
    IF checkbarcode = 0 then 
        set num = (select max(id) from purchase_order ); 
        set num = IFNULL(num, 0);
        set num = num +1;
        SET NEW.code = CONCAT('NH', LPAD(num, 7, '0'));
	END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_product`
--

CREATE TABLE IF NOT EXISTS `purchase_product` (
  `id` int(11) NOT NULL,
  `barcode` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `original_price` bigint(11) NOT NULL DEFAULT '0',
  `price` bigint(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `discount_amount` int(11) NOT NULL DEFAULT '0',
  `total_money` bigint(11) NOT NULL DEFAULT '0',
  `inventory_number` int(11) NOT NULL DEFAULT '0',
  `inventory_number_real` int(11) NOT NULL DEFAULT '0',
  `balance` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `invoice_id` int(11) NOT NULL DEFAULT '0',
  `return_id` int(11) NOT NULL DEFAULT '0',
  `purchase_order_id` int(11) NOT NULL DEFAULT '0',
  `purchase_return_id` int(11) NOT NULL DEFAULT '0',
  `transfer_id` int(11) NOT NULL DEFAULT '0',
  `damage_item_id` int(11) NOT NULL DEFAULT '0',
  `inventory_control_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `updated` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `purchase_product`
--

INSERT INTO `purchase_product` (`id`, `barcode`, `code`, `name`, `original_price`, `price`, `number`, `discount_amount`, `total_money`, `inventory_number`, `inventory_number_real`, `balance`, `order_id`, `invoice_id`, `return_id`, `purchase_order_id`, `purchase_return_id`, `transfer_id`, `damage_item_id`, `inventory_control_id`, `is_deleted`, `created`, `updated`) VALUES
(1, '213dasd', '', 'Nước hoa Rose', 123, 213213, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2016-06-10 10:42:06', '2016-06-10 10:42:06'),
(2, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, '2016-06-10 14:06:56', '2016-06-10 14:06:56'),
(3, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 213213, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, '2016-06-10 15:35:45', '2016-06-10 15:35:45'),
(4, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 10, 0, '2016-06-10 15:38:10', '2016-06-10 15:38:10'),
(5, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 213213, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, '2016-06-10 15:39:28', '2016-06-10 15:39:28'),
(6, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 213213, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, '2016-06-10 15:40:08', '2016-06-10 15:40:08'),
(7, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 213213, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, '2016-06-10 15:48:14', '2016-06-10 15:48:14'),
(8, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 0, 0, 0, 2, 10, 8, 0, 0, 0, 0, 0, 0, 0, 11, 0, '2016-06-10 15:56:52', '2016-06-10 15:56:52'),
(9, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 213213, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '2016-06-10 16:04:43', '2016-06-10 16:04:43'),
(10, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 213213, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '2016-06-10 16:43:02', '2016-06-10 16:43:02'),
(11, 'SP0000001', '', 'Nước hoa Rose', 123, 213213, 10, 0, 1230, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, '2016-06-10 17:03:04', '2016-06-10 17:03:04'),
(12, 'SP0000001', '', 'Nước hoa Rose', 123, 213213, 10, 0, 1230, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, '2016-06-10 17:04:18', '2016-06-10 17:04:18'),
(13, 'SP0000001', '', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, '2016-06-10 17:04:29', '2016-06-10 17:04:29'),
(14, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 4, 0, 492, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 1, '2016-06-10 17:15:23', '2016-06-10 17:15:23'),
(15, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 10, 0, 1230, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, '2016-06-10 17:16:40', '2016-06-10 17:16:40'),
(16, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 10, 0, 1230, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, '2016-06-10 17:17:03', '2016-06-10 17:17:03'),
(17, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, '2016-06-10 17:28:30', '2016-06-10 17:28:30'),
(18, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 2, 0, 246, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, '2016-06-10 17:29:21', '2016-06-10 17:29:21'),
(19, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 1, '2016-06-10 17:35:55', '2016-06-10 17:35:55'),
(20, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 1, '2016-06-10 17:36:26', '2016-06-10 17:36:26'),
(21, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 1, '2016-06-10 17:41:17', '2016-06-10 17:41:17'),
(22, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, '2016-06-10 17:42:36', '2016-06-10 17:42:36'),
(23, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 1, '2016-06-10 17:46:44', '2016-06-10 17:46:44'),
(24, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, '2016-06-13 08:15:34', '2016-06-13 08:15:34'),
(25, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 2, 0, 246, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '2016-06-13 08:46:26', '2016-06-13 08:46:26'),
(26, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1, '2016-06-13 08:50:40', '2016-06-13 08:50:40'),
(27, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 2, 0, 426426, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, '2016-06-13 09:50:33', '2016-06-13 09:50:33'),
(28, 'SP0000001', '213dasd', 'Nước hoa Rose', 123, 213213, 3, 0, 639639, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, '2016-06-13 09:55:17', '2016-06-13 09:55:17');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_return`
--

CREATE TABLE IF NOT EXISTS `purchase_return` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) DEFAULT '0',
  `status` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_product` int(11) NOT NULL,
  `total_money_product` bigint(11) NOT NULL,
  `purchase_order_id` int(11) DEFAULT '0',
  `guest_pay_money` bigint(11) NOT NULL,
  `is_deleted` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `purchase_return`
--

INSERT INTO `purchase_return` (`id`, `code`, `customer_id`, `status`, `branch_id`, `user_id`, `note`, `total_product`, `total_money_product`, `purchase_order_id`, `guest_pay_money`, `is_deleted`, `created`) VALUES
(1, 'TH0000001', 2, 0, 1, 1, '', 1, 123, 6, 123, 1, '2016-06-10 17:28:30'),
(2, 'TH0000002', 2, 0, 1, 1, '', 2, 246, 6, 246, 1, '2016-06-10 17:29:21'),
(3, 'TH0000003', 2, 0, 1, 1, '', 1, 123, 6, 123, 1, '2016-06-10 17:35:55'),
(4, 'TH0000004', 2, 0, 1, 1, '', 1, 123, 6, 123, 1, '2016-06-10 17:36:26'),
(5, 'TH0000005', 2, 0, 1, 1, '', 1, 123, 6, 123, 1, '2016-06-10 17:41:17'),
(6, 'TH0000006', 2, 0, 1, 1, '', 1, 123, 6, 123, 0, '2016-06-10 17:42:36'),
(7, 'TH0000007', 2, 0, 1, 1, '', 1, 123, 6, 123, 1, '2016-06-10 17:46:44'),
(8, 'TH0000008', 2, 0, 1, 1, '', 1, 123, 6, 123, 0, '2016-06-13 08:15:34');

--
-- Triggers `purchase_return`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_purchase_return` BEFORE INSERT ON `purchase_return`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
	set num = (select max(id) from purchase_return ); 
    set num = IFNULL(num, 0);
    set num = num +1;
	SET NEW.code = CONCAT('TH', LPAD(num, 7, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `returns`
--

CREATE TABLE IF NOT EXISTS `returns` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) DEFAULT '0',
  `status` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_money_product` bigint(11) NOT NULL,
  `cash_discount` int(11) NOT NULL,
  `guest_pay_money` bigint(11) NOT NULL,
  `fee_return` int(11) DEFAULT '0',
  `is_deleted` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `returns`
--

INSERT INTO `returns` (`id`, `code`, `customer_id`, `status`, `invoice_id`, `user_id`, `branch_id`, `note`, `total_money_product`, `cash_discount`, `guest_pay_money`, `fee_return`, `is_deleted`, `created`) VALUES
(1, 'TH0000001', 0, 0, 4, 1, 1, '', 213213, 0, 213213, 0, 0, '2016-06-10 16:43:02');

--
-- Triggers `returns`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_return` BEFORE INSERT ON `returns`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
	set num = (select max(id) from returns ); 
    set num = IFNULL(num, 0);
    set num = num +1;
	SET NEW.code = CONCAT('TH', LPAD(num, 7, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `surcharge`
--

CREATE TABLE IF NOT EXISTS `surcharge` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `ordinal` int(11) NOT NULL,
  `add_bill` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_deleted` int(11) DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Triggers `surcharge`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_surcharge` BEFORE INSERT ON `surcharge`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
	set num = (select max(id) from surcharge ); 
    set num = IFNULL(num, 0);
    set num = num +1;
	SET NEW.code = CONCAT('TKH', LPAD(num, 6, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `transfers`
--

CREATE TABLE IF NOT EXISTS `transfers` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `branch_transport` int(11) NOT NULL,
  `branch_receiver` int(11) NOT NULL,
  `date_transport` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `date_receiver` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `note` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_product` int(11) NOT NULL,
  `total_money_product` bigint(11) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transfers`
--

INSERT INTO `transfers` (`id`, `code`, `branch_transport`, `branch_receiver`, `date_transport`, `date_receiver`, `user_id`, `status`, `note`, `total_product`, `total_money_product`, `is_deleted`, `created`) VALUES
(1, 'TRF000001', 1, 2, '2016-06-13 00:00:00', '2016-06-15 00:00:00', 1, 0, '', 2, 246, 0, '2016-06-13 08:46:26'),
(2, 'TRF000002', 1, 2, '2016-06-13 00:00:00', '2016-06-15 00:00:00', 1, 0, '', 1, 123, 1, '2016-06-13 08:50:40');

--
-- Triggers `transfers`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_transfers` BEFORE INSERT ON `transfers`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
	set num = (select max(id) from transfers ); 
    set num = IFNULL(num, 0);
    set num = num +1;
	SET NEW.code = CONCAT('TRF', LPAD(num, 6, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_full_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_day` datetime DEFAULT '2016-01-01 00:00:00',
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `updated` datetime NOT NULL DEFAULT '2016-01-01 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `code`, `username`, `password`, `user_full_name`, `birth_day`, `phone`, `address`, `email`, `role`, `parent_id`, `is_deleted`, `created`, `updated`) VALUES
(1, 'NV0000001', 'Administrator', '$2a$08$iLeUt8bHvm03Q.OffV8wsuU.IBnSG1UMl37t7yuwUNci162Pp/rkG', 'Administrator', '2016-01-01 00:00:00', '01231944123', 'quan 9', 'admin@gmail.com', 19, 0, 0, '2016-01-01 00:00:00', '2016-06-13 10:27:00');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `auto_incre_code_users` BEFORE INSERT ON `users`
 FOR EACH ROW BEGIN
DECLARE num int default 0;	
	set num = (select max(id) from users ); 
    set num = IFNULL(num, 0);
    set num = num +1;
	SET NEW.code = CONCAT('NV', LPAD(num, 7, '0'));
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cash_flow`
--
ALTER TABLE `cash_flow`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `damage_items`
--
ALTER TABLE `damage_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_control`
--
ALTER TABLE `inventory_control`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `meta`
--
ALTER TABLE `meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `meta_group` (`meta_group`),
  ADD KEY `meta_key` (`meta_key`(255)),
  ADD KEY `meta_value` (`meta_value`(255));

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `order_invoice_surcharge`
--
ALTER TABLE `order_invoice_surcharge`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `barcode` (`barcode`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `product_extension`
--
ALTER TABLE `product_extension`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `purchase_product`
--
ALTER TABLE `purchase_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `barcode` (`barcode`);

--
-- Indexes for table `purchase_return`
--
ALTER TABLE `purchase_return`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `returns`
--
ALTER TABLE `returns`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `surcharge`
--
ALTER TABLE `surcharge`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `transfers`
--
ALTER TABLE `transfers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cash_flow`
--
ALTER TABLE `cash_flow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `damage_items`
--
ALTER TABLE `damage_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `inventory_control`
--
ALTER TABLE `inventory_control`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `meta`
--
ALTER TABLE `meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=503;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `order_invoice_surcharge`
--
ALTER TABLE `order_invoice_surcharge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product_extension`
--
ALTER TABLE `product_extension`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `purchase_order`
--
ALTER TABLE `purchase_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `purchase_product`
--
ALTER TABLE `purchase_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `purchase_return`
--
ALTER TABLE `purchase_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `returns`
--
ALTER TABLE `returns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `surcharge`
--
ALTER TABLE `surcharge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transfers`
--
ALTER TABLE `transfers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
